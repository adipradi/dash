import streamlit as st
from auth.utils import check_password, get_client_ip
from database.db_connection import get_connection
from auth.audit_log import log_user_activity
import hashlib

def login():
    """Main login function with authentication and session management"""
    st.title("🔐 Login")
    
    # Create login form
    with st.form("login_form"):
        username = st.text_input("Username", placeholder="Enter your username")
        password = st.text_input("Password", type="password", placeholder="Enter your password")
        submit_button = st.form_submit_button("Login", use_container_width=True)
    
    if submit_button:
        if not username or not password:
            st.warning("⚠️ Please fill in all fields.")
            return False
        
        try:
            conn = get_connection()
            cursor = conn.cursor()
            
            # Query user with case-insensitive username
            cursor.execute("""
                SELECT id, username, password_hash, role, created_at, last_login 
                FROM users 
                WHERE LOWER(username) = LOWER(%s)
            """, (username,))
            
            result = cursor.fetchone()
            
            if result:
                user_id, user_name, stored_hash, role, created_at, last_login = result
                
                if check_password(password, stored_hash):
                    # Set session state
                    st.session_state.logged_in = True
                    st.session_state.user_id = user_id
                    st.session_state.username = user_name
                    st.session_state.role = role
                    st.session_state.login_time = st.session_state.get('login_time', None)
                    
                    # Get client IP
                    ip = get_client_ip()
                    
                    # Log successful login
                    log_user_activity(
                        user_id, 
                        "login_success", 
                        ip, 
                        {"username": user_name, "role": role}
                    )
                    
                    # Update last login time
                    cursor.execute("""
                        UPDATE users 
                        SET last_login = CURRENT_TIMESTAMP 
                        WHERE id = %s
                    """, (user_id,))
                    conn.commit()
                    
                    st.success(f"✅ Welcome back, {user_name}!")
                    st.balloons()
                    
                    # Small delay before rerun for better UX
                    import time
                    time.sleep(1)
                    st.rerun()
                    
                else:
                    # Log failed login attempt
                    ip = get_client_ip()
                    log_user_activity(
                        None, 
                        "login_failed", 
                        ip, 
                        {"attempted_username": username, "reason": "wrong_password"}
                    )
                    st.error("❌ Incorrect password.")
                    
            else:
                # Log failed login attempt - user not found
                ip = get_client_ip()
                log_user_activity(
                    None, 
                    "login_failed", 
                    ip, 
                    {"attempted_username": username, "reason": "user_not_found"}
                )
                st.error("❌ Username not found.")
                
        except Exception as e:
            st.error(f"❌ Login error: {str(e)}")
            
        finally:
            if 'conn' in locals():
                conn.close()
                
    return False

def logout():
    """Logout function with audit logging"""
    if st.session_state.get('logged_in', False):
        user_id = st.session_state.get('user_id')
        username = st.session_state.get('username')
        
        # Log logout activity
        ip = get_client_ip()
        log_user_activity(
            user_id, 
            "logout", 
            ip, 
            {"username": username}
        )
        
        # Clear session state
        for key in list(st.session_state.keys()):
            del st.session_state[key]
            
        st.success("✅ Successfully logged out!")
        st.rerun()

def is_authenticated():
    """Check if user is authenticated"""
    return st.session_state.get('logged_in', False)

def get_current_user():
    """Get current user information"""
    if is_authenticated():
        return {
            'user_id': st.session_state.get('user_id'),
            'username': st.session_state.get('username'),
            'role': st.session_state.get('role')
        }
    return None

def require_auth():
    """Decorator to require authentication for pages"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            if not is_authenticated():
                st.warning("🔒 Please login to access this page.")
                login()
                return None
            return func(*args, **kwargs)
        return wrapper
    return decorator