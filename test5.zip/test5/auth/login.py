import streamlit as st
import hashlib
import json
import os

# Simple user database (dalam production gunakan database yang proper)
USERS_FILE = "users.json"

def init_users_file():
    """Initialize users file with default admin account"""
    if not os.path.exists(USERS_FILE):
        default_users = {
            "admin": {
                "password": hashlib.sha256("Admin@123".encode()).hexdigest(),
                "role": "admin",
                "user_id": 1,
                "email": "admin@example.com",
                "full_name": "System Administrator",
                "created_at": "2024-01-01",
                "avatar": None
            }
        }
        with open(USERS_FILE, 'w') as f:
            json.dump(default_users, f, indent=2)

def load_users():
    """Load users from file"""
    init_users_file()
    try:
        with open(USERS_FILE, 'r') as f:
            return json.load(f)
    except:
        return {}

def save_users(users):
    """Save users to file"""
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=2)

def login():
    """Login form and authentication"""
    st.subheader("🔑 Login")
    
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        remember_me = st.checkbox("Remember me")
        
        submitted = st.form_submit_button("Login", type="primary", use_container_width=True)
        
        if submitted:
            if authenticate_user(username, password):
                st.success("Login successful!")
                st.rerun()
            else:
                st.error("Invalid username or password")

def authenticate_user(username, password):
    """Authenticate user credentials"""
    users = load_users()
    
    if username in users:
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        if users[username]["password"] == hashed_password:
            # Set session state
            st.session_state.authenticated = True
            st.session_state.username = username
            st.session_state.user_id = users[username]["user_id"]
            st.session_state.role = users[username]["role"]
            
            # Log successful login
            try:
                from auth.audit_log import log_activity
                from auth.utils import get_client_ip
                log_activity(
                    user_id=users[username]["user_id"],
                    action="LOGIN",
                    details=f"Successful login for user: {username}",
                    ip_address=get_client_ip(),
                    success=True
                )
            except:
                pass  # Continue even if logging fails
            
            return True
    
    # Log failed login attempt
    try:
        from auth.audit_log import log_activity
        from auth.utils import get_client_ip
        log_activity(
            user_id=None,
            action="FAILED_LOGIN",
            details=f"Failed login attempt for username: {username}",
            ip_address=get_client_ip(),
            success=False
        )
    except:
        pass
    
    return False

def logout():
    """Logout and clear session"""
    try:
        from auth.audit_log import log_activity
        from auth.utils import get_client_ip
        log_activity(
            user_id=st.session_state.get('user_id'),
            action="LOGOUT",
            details=f"User logout: {st.session_state.get('username')}",
            ip_address=get_client_ip(),
            success=True
        )
    except:
        pass
    
    # Clear session state
    for key in list(st.session_state.keys()):
        del st.session_state[key]
    
    st.rerun()

def is_authenticated():
    """Check if user is authenticated"""
    return st.session_state.get('authenticated', False)

def get_current_user():
    """Get current user information"""
    if is_authenticated():
        users = load_users()
        username = st.session_state.get('username')
        if username in users:
            user_data = users[username].copy()
            user_data['username'] = username
            return user_data
    return None

