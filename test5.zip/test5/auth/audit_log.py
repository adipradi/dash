import json
from datetime import datetime, timedelta
from database.db_connection import get_connection
import streamlit as st

def log_user_activity(user_id, action, ip_address, metadata=None):
    """
    Log user activity to audit_logs table
    
    Args:
        user_id: User ID (can be None for failed logins)
        action: Action performed (login, logout, view_page, etc.)
        ip_address: Client IP address
        metadata: Additional data as dict
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        timestamp = datetime.utcnow()
        metadata_json = json.dumps(metadata or {})
        
        query = """
            INSERT INTO audit_logs (user_id, action, ip_address, timestamp, metadata)
            VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(query, (user_id, action, ip_address, timestamp, metadata_json))
        conn.commit()
        
    except Exception as e:
        st.error(f"Error logging activity: {str(e)}")
    finally:
        if 'conn' in locals():
            conn.close()

def get_user_activities(user_id=None, limit=100, days=30):
    """
    Retrieve user activities from audit logs
    
    Args:
        user_id: Specific user ID (None for all users)
        limit: Maximum number of records
        days: Number of days to look back
    
    Returns:
        List of activity records
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Calculate date range
        start_date = datetime.utcnow() - timedelta(days=days)
        
        if user_id:
            query = """
                SELECT al.id, al.user_id, u.username, al.action, al.ip_address, 
                       al.timestamp, al.metadata
                FROM audit_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE al.user_id = %s AND al.timestamp >= %s
                ORDER BY al.timestamp DESC
                LIMIT %s
            """
            cursor.execute(query, (user_id, start_date, limit))
        else:
            query = """
                SELECT al.id, al.user_id, u.username, al.action, al.ip_address, 
                       al.timestamp, al.metadata
                FROM audit_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE al.timestamp >= %s
                ORDER BY al.timestamp DESC
                LIMIT %s
            """
            cursor.execute(query, (start_date, limit))
        
        results = cursor.fetchall()
        
        # Convert to list of dicts
        activities = []
        for row in results:
            activity = {
                'id': row[0],
                'user_id': row[1],
                'username': row[2] or 'Unknown',
                'action': row[3],
                'ip_address': row[4],
                'timestamp': row[5],
                'metadata': json.loads(row[6]) if row[6] else {}
            }
            activities.append(activity)
        
        return activities
        
    except Exception as e:
        st.error(f"Error retrieving activities: {str(e)}")
        return []
    finally:
        if 'conn' in locals():
            conn.close()

def get_login_attempts(days=7, failed_only=False):
    """
    Get login attempts for security monitoring
    
    Args:
        days: Number of days to look back
        failed_only: Show only failed attempts
    
    Returns:
        List of login attempt records
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        start_date = datetime.utcnow() - timedelta(days=days)
        
        if failed_only:
            query = """
                SELECT al.ip_address, al.timestamp, al.metadata, COUNT(*) as attempt_count
                FROM audit_logs al
                WHERE al.action = 'login_failed' AND al.timestamp >= %s
                GROUP BY al.ip_address, DATE(al.timestamp)
                ORDER BY attempt_count DESC, al.timestamp DESC
            """
        else:
            query = """
                SELECT al.user_id, u.username, al.action, al.ip_address, 
                       al.timestamp, al.metadata
                FROM audit_logs al
                LEFT JOIN users u ON al.user_id = u.id
                WHERE al.action IN ('login_success', 'login_failed') 
                AND al.timestamp >= %s
                ORDER BY al.timestamp DESC
            """
        
        cursor.execute(query, (start_date,))
        results = cursor.fetchall()
        
        return results
        
    except Exception as e:
        st.error(f"Error retrieving login attempts: {str(e)}")
        return []
    finally:
        if 'conn' in locals():
            conn.close()

def get_activity_stats(days=30):
    """
    Get activity statistics for dashboard
    
    Args:
        days: Number of days to analyze
    
    Returns:
        Dict with activity statistics
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        start_date = datetime.utcnow() - timedelta(days=days)
        
        # Total activities
        cursor.execute("""
            SELECT COUNT(*) FROM audit_logs 
            WHERE timestamp >= %s
        """, (start_date,))
        total_activities = cursor.fetchone()[0]
        
        # Unique users active
        cursor.execute("""
            SELECT COUNT(DISTINCT user_id) FROM audit_logs 
            WHERE timestamp >= %s AND user_id IS NOT NULL
        """, (start_date,))
        active_users = cursor.fetchone()[0]
        
        # Failed login attempts
        cursor.execute("""
            SELECT COUNT(*) FROM audit_logs 
            WHERE action = 'login_failed' AND timestamp >= %s
        """, (start_date,))
        failed_logins = cursor.fetchone()[0]
        
        # Top actions
        cursor.execute("""
            SELECT action, COUNT(*) as count
            FROM audit_logs 
            WHERE timestamp >= %s
            GROUP BY action
            ORDER BY count DESC
            LIMIT 10
        """, (start_date,))
        top_actions = cursor.fetchall()
        
        # Activity by day
        cursor.execute("""
            SELECT DATE(timestamp) as date, COUNT(*) as count
            FROM audit_logs 
            WHERE timestamp >= %s
            GROUP BY DATE(timestamp)
            ORDER BY date DESC
            LIMIT 30
        """, (start_date,))
        daily_activity = cursor.fetchall()
        
        return {
            'total_activities': total_activities,
            'active_users': active_users,
            'failed_logins': failed_logins,
            'top_actions': top_actions,
            'daily_activity': daily_activity
        }
        
    except Exception as e:
        st.error(f"Error getting activity stats: {str(e)}")
        return {}
    finally:
        if 'conn' in locals():
            conn.close()

def clean_old_logs(days_to_keep=90):
    """
    Clean up old audit logs to prevent database bloat
    
    Args:
        days_to_keep: Number of days to retain logs
    
    Returns:
        Number of records deleted
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cutoff_date = datetime.utcnow() - timedelta(days=days_to_keep)
        
        cursor.execute("""
            DELETE FROM audit_logs 
            WHERE timestamp < %s
        """, (cutoff_date,))
        
        deleted_count = cursor.rowcount
        conn.commit()
        
        return deleted_count
        
    except Exception as e:
        st.error(f"Error cleaning old logs: {str(e)}")
        return 0
    finally:
        if 'conn' in locals():
            conn.close()

def export_audit_logs(start_date=None, end_date=None, user_id=None):
    """
    Export audit logs for compliance/analysis
    
    Args:
        start_date: Start date for export
        end_date: End date for export  
        user_id: Specific user ID (optional)
    
    Returns:
        List of audit log records
    """
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Default to last 30 days if no dates provided
        if not start_date:
            start_date = datetime.utcnow() - timedelta(days=30)
        if not end_date:
            end_date = datetime.utcnow()
        
        base_query = """
            SELECT al.id, al.user_id, u.username, al.action, al.ip_address, 
                   al.timestamp, al.metadata
            FROM audit_logs al
            LEFT JOIN users u ON al.user_id = u.id
            WHERE al.timestamp BETWEEN %s AND %s
        """
        
        params = [start_date, end_date]
        
        if user_id:
            base_query += " AND al.user_id = %s"
            params.append(user_id)
        
        base_query += " ORDER BY al.timestamp DESC"
        
        cursor.execute(base_query, params)
        results = cursor.fetchall()
        
        # Convert to structured format
        logs = []
        for row in results:
            log_entry = {
                'id': row[0],
                'user_id': row[1],
                'username': row[2] or 'System',
                'action': row[3],
                'ip_address': row[4],
                'timestamp': row[5].isoformat() if row[5] else None,
                'metadata': json.loads(row[6]) if row[6] else {}
            }
            logs.append(log_entry)
        
        return logs
        
    except Exception as e:
        st.error(f"Error exporting audit logs: {str(e)}")
        return []
    finally:
        if 'conn' in locals():
            conn.close()