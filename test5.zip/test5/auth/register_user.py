import streamlit as st
from database.db_connection import get_connection
from auth.utils import hash_password, validate_username, is_password_strong, get_client_ip
from auth.audit_log import log_user_activity
from auth.rbac import get_assignable_roles, has_permission, require_permission
import re

@require_permission('manage_users')
def register_user():
    """User registration form for admins"""
    st.title("👥 Register New User")
    
    with st.form("register_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            username = st.text_input(
                "Username *", 
                placeholder="Enter username",
                help="Username must be 3-50 characters, alphanumeric and underscore only"
            )
            password = st.text_input(
                "Password *", 
                type="password",
                help="Password must be strong (8+ chars, upper, lower, number, special char)"
            )
            confirm_password = st.text_input("Confirm Password *", type="password")
        
        with col2:
            full_name = st.text_input("Full Name", placeholder="Enter full name")
            email = st.text_input("Email", placeholder="Enter email address")
            
            # Role selection based on current user's permissions
            assignable_roles = get_assignable_roles()
            role = st.selectbox(
                "Role *", 
                options=assignable_roles,
                help="Select user role and permissions"
            )
        
        is_active = st.checkbox("Active User", value=True)
        
        submit_button = st.form_submit_button("Create User", use_container_width=True)
    
    if submit_button:
        # Validation
        errors = []
        
        # Username validation
        is_valid_username, username_msg = validate_username(username)
        if not is_valid_username:
            errors.append(username_msg)
        
        # Password validation
        if not password:
            errors.append("Password is required")
        elif password != confirm_password:
            errors.append("Passwords do not match")
        else:
            is_strong, password_msg = is_password_strong(password)
            if not is_strong:
                errors.append(password_msg)
        
        # Email validation (optional but must be valid if provided)
        if email and not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
            errors.append("Invalid email format")
        
        # Role validation
        if role not in assignable_roles:
            errors.append("Invalid role selection")
        
        if errors:
            for error in errors:
                st.error(f" {error}")
            return
        
        # Check if username already exists
        if check_username_exists(username):
            st.error("Username already exists")
            return
        
        # Create user
        success = create_user(username, password, role, email, full_name, is_active)
        
        if success:
            st.success(f"User '{username}' created successfully!")
            
            # Log user creation
            ip = get_client_ip()
            log_user_activity(
                st.session_state.get('user_id'),
                'user_created',
                ip,
                {
                    'created_username': username,
                    'created_role': role,
                    'admin_username': st.session_state.get('username')
                }
            )
            
            # Show user details
            with st.expander("User Details", expanded=True):
                st.write(f"**Username:** {username}")
                st.write(f"**Role:** {role}")
                st.write(f"**Full Name:** {full_name or 'Not provided'}")
                st.write(f"**Email:** {email or 'Not provided'}")
                st.write(f"**Status:** {'Active' if is_active else 'Inactive'}")
        else:
            st.error("Failed to create user")

def check_username_exists(username):
    """Check if username already exists"""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT id FROM users WHERE LOWER(username) = LOWER(%s)", (username,))
        result = cursor.fetchone()
        
        return result is not None
        
    except Exception as e:
        st.error(f"Error checking username: {str(e)}")
        return True  # Assume exists to prevent duplicates on error
    finally:
        if 'conn' in locals():
            conn.close()

def create_user(username, password, role, email=None, full_name=None, is_active=True):
    """Create new user in database"""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Hash password with salt
        password_hash = hash_password(password)
        
        query = """
            INSERT INTO users (username, password_hash, role, email, full_name, is_active)
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        
        cursor.execute(query, (username, password_hash, role, email, full_name, is_active))
        conn.commit()
        
        return True
        
    except Exception as e:
        st.error(f"Error creating user: {str(e)}")
        return False
    finally:
        if 'conn' in locals():
            conn.close()

@require_permission('manage_users')
def manage_users():
    """User management interface"""
    st.title("👥 User Management")
    
    # Tabs for different actions
    tab1, tab2, tab3 = st.tabs(["View Users", "Edit User", "Bulk Actions"])
    
    with tab1:
        display_users_table()
    
    with tab2:
        edit_user_interface()
    
    with tab3:
        bulk_user_actions()

def display_users_table():
    """Display users in a table format"""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        # Get users with additional info
        query = """
            SELECT id, username, role, email, full_name, is_active, 
                   created_at, last_login, failed_login_attempts
            FROM users 
            ORDER BY created_at DESC
        """
        
        cursor.execute(query)
        users = cursor.fetchall()
        
        if not users:
            st.info("No users found")
            return
        
        # Display filters
        col1, col2, col3 = st.columns(3)
        with col1:
            role_filter = st.selectbox("Filter by Role", ["All"] + list(set([user[2] for user in users])))
        with col2:
            status_filter = st.selectbox("Filter by Status", ["All", "Active", "Inactive"])
        with col3:
            search_term = st.text_input("Search Username")
        
        # Apply filters
        filtered_users = users
        if role_filter != "All":
            filtered_users = [u for u in filtered_users if u[2] == role_filter]
        if status_filter != "All":
            is_active_filter = status_filter == "Active"
            filtered_users = [u for u in filtered_users if u[5] == is_active_filter]
        if search_term:
            filtered_users = [u for u in filtered_users if search_term.lower() in u[1].lower()]
        
        # Display users table
        st.write(f"**Total Users:** {len(filtered_users)}")
        
        for user in filtered_users:
            user_id, username, role, email, full_name, is_active, created_at, last_login, failed_attempts = user
            
            with st.expander(f"👤 {username} ({role})", expanded=False):
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write(f"**ID:** {user_id}")
                    st.write(f"**Username:** {username}")
                    st.write(f"**Role:** {role}")
                    st.write(f"**Status:** {'Active' if is_active else 'Inactive'}")
                
                with col2:
                    st.write(f"**Email:** {email or 'Not provided'}")
                    st.write(f"**Full Name:** {full_name or 'Not provided'}")
                    st.write(f"**Created:** {created_at}")
                    st.write(f"**Last Login:** {last_login or 'Never'}")
                
                if failed_attempts > 0:
                    st.warning(f"Failed login attempts: {failed_attempts}")
                
                # Action buttons
                col1, col2, col3 = st.columns(3)
                with col1:
                    if st.button(f"Edit {username}", key=f"edit_{user_id}"):
                        st.session_state.edit_user_id = user_id
                
                with col2:
                    if st.button(f"Reset Password", key=f"reset_{user_id}"):
                        st.session_state.reset_password_user_id = user_id
                
                with col3:
                    action = "Deactivate" if is_active else "Activate"
                    if st.button(f"{action}", key=f"toggle_{user_id}"):
                        toggle_user_status(user_id, username, not is_active)
                        st.rerun()
        
    except Exception as e:
        st.error(f"Error loading users: {str(e)}")
    finally:
        if 'conn' in locals():
            conn.close()

def edit_user_interface():
    """Interface for editing user details"""
    if 'edit_user_id' not in st.session_state:
        st.info("Select a user to edit from the View Users tab")
        return
    
    user_id = st.session_state.edit_user_id
    user_data = get_user_by_id(user_id)
    
    if not user_data:
        st.error("User not found")
        return
    
    st.subheader(f"Edit User: {user_data['username']}")
    
    with st.form("edit_user_form"):
        full_name = st.text_input("Full Name", value=user_data.get('full_name', '') or '')
        email = st.text_input("Email", value=user_data.get('email', '') or '')
        
        assignable_roles = get_assignable_roles()
        current_role_index = assignable_roles.index(user_data['role']) if user_data['role'] in assignable_roles else 0
        role = st.selectbox("Role", options=assignable_roles, index=current_role_index)
        
        is_active = st.checkbox("Active User", value=user_data['is_active'])
        
        if st.form_submit_button("Update User"):
            if update_user(user_id, full_name, email, role, is_active):
                st.success("User updated successfully!")
                
                # Log user update
                ip = get_client_ip()
                log_user_activity(
                    st.session_state.get('user_id'),
                    'user_updated',
                    ip,
                    {
                        'updated_user_id': user_id,
                        'updated_username': user_data['username'],
                        'admin_username': st.session_state.get('username')
                    }
                )
                
                del st.session_state.edit_user_id
                st.rerun()
            else:
                st.error("Failed to update user")

def get_user_by_id(user_id):
    """Get user details by ID"""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT id, username, role, email, full_name, is_active, 
                   created_at, last_login
            FROM users WHERE id = %s
        """, (user_id,))
        
        result = cursor.fetchone()
        if result:
            return {
                'id': result[0],
                'username': result[1],
                'role': result[2],
                'email': result[3],
                'full_name': result[4],
                'is_active': result[5],
                'created_at': result[6],
                'last_login': result[7]
            }
        return None
        
    except Exception as e:
        st.error(f"Error getting user: {str(e)}")
        return None
    finally:
        if 'conn' in locals():
            conn.close()

def update_user(user_id, full_name, email, role, is_active):
    """Update user details"""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        query = """
            UPDATE users 
            SET full_name = %s, email = %s, role = %s, is_active = %s,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = %s
        """
        
        cursor.execute(query, (full_name, email, role, is_active, user_id))
        conn.commit()
        
        return cursor.rowcount > 0
        
    except Exception as e:
        st.error(f"Error updating user: {str(e)}")
        return False
    finally:
        if 'conn' in locals():
            conn.close()

def toggle_user_status(user_id, username, is_active):
    """Toggle user active status"""
    try:
        conn = get_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            UPDATE users 
            SET is_active = %s, updated_at = CURRENT_TIMESTAMP
            WHERE id = %s
        """, (is_active, user_id))
        
        conn.commit()
        
        status = "activated" if is_active else "deactivated"
        st.success(f"User {username} {status}")
        
        # Log status change
        ip = get_client_ip()
        log_user_activity(
            st.session_state.get('user_id'),
            f'user_{status}',
            ip,
            {
                'target_user_id': user_id,
                'target_username': username,
                'admin_username': st.session_state.get('username')
            }
        )
        
    except Exception as e:
        st.error(f"Error updating user status: {str(e)}")
    finally:
        if 'conn' in locals():
            conn.close()

def bulk_user_actions():
    """Bulk actions for user management"""
    st.subheader("Bulk User Actions")
    
    action = st.selectbox(
        "Select Action",
        ["Select Action", "Export User List", "Bulk Role Update", "Cleanup Inactive Users"]
    )
    
    if action == "Export User List":
        if st.button("Export to CSV"):
            # Implementation for CSV export
            st.info("Export functionality would be implemented here")
    
    elif action == "Bulk Role Update":
        st.write("Update multiple users' roles at once")
        # Implementation for bulk role update
        
    elif action == "Cleanup Inactive Users":
        st.write("Remove users who haven't logged in for a specified period")
        # Implementation for cleanup