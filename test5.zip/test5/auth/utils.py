import hashlib
import streamlit as st
import secrets
import hmac
from datetime import datetime, timedelta

def hash_password(password, salt=None):
    """
    Hash password with salt using SHA-256
    Returns tuple: (hashed_password, salt)
    """
    if salt is None:
        salt = secrets.token_hex(16)  
    
    # Combine password and salt
    salted_password = password + salt
    
    # Hash with SHA-256
    hashed = hashlib.sha256(salted_password.encode()).hexdigest()
    
    # Return combined hash:salt format
    return f"{hashed}:{salt}"

def check_password(input_password, stored_hash):
    """
    Verify password against stored hash
    stored_hash format: "hash:salt"
    """
    try:
        if ":" in stored_hash:
            # New format with salt
            stored_hash_part, salt = stored_hash.split(":", 1)
            input_hash = hashlib.sha256((input_password + salt).encode()).hexdigest()
            return hmac.compare_digest(stored_hash_part, input_hash)
        else:
            # Legacy format without salt (for backward compatibility)
            input_hash = hashlib.sha256(input_password.encode()).hexdigest()
            return hmac.compare_digest(stored_hash, input_hash)
    except Exception:
        return False

def get_client_ip():
    """
    Get client IP address from Streamlit request headers
    """
    try:
        # Try to get real IP from reverse proxy headers
        headers = st.context.headers if hasattr(st.context, 'headers') else {}
        
        # Check common proxy headers
        proxy_headers = [
            'X-Forwarded-For',
            'X-Real-IP', 
            'X-Client-IP',
            'CF-Connecting-IP'  
        ]
        
        for header in proxy_headers:
            if header in headers:
                ip = headers[header].split(',')[0].strip()
                if ip and ip != 'unknown':
                    return ip
        
        # Fallback to remote address
        return getattr(st.context, 'remote_addr', 'unknown')
        
    except Exception:
        # Ultimate fallback
        return 'unknown'

def generate_session_token():
    """Generate secure session token"""
    return secrets.token_urlsafe(32)

def is_password_strong(password):
    """
    Check if password meets security requirements
    Returns: (is_strong: bool, message: str)
    """
    if len(password) < 8:
        return False, "Password must be at least 8 characters long"
    
    if not any(c.isupper() for c in password):
        return False, "Password must contain at least one uppercase letter"
    
    if not any(c.islower() for c in password):
        return False, "Password must contain at least one lowercase letter"
    
    if not any(c.isdigit() for c in password):
        return False, "Password must contain at least one number"
    
    special_chars = "!@#$%^&*()_+-=[]{}|;:,.<>?"
    if not any(c in special_chars for c in password):
        return False, "Password must contain at least one special character"
    
    return True, "Password is strong"

def sanitize_input(input_str):
    """Basic input sanitization"""
    if not input_str:
        return ""
    
    # Remove potential SQL injection characters
    dangerous_chars = ["'", '"', ';', '--', '/*', '*/', 'xp_', 'sp_']
    
    for char in dangerous_chars:
        input_str = input_str.replace(char, '')
    
    return input_str.strip()

def format_datetime(dt):
    """Format datetime for display"""
    if dt is None:
        return "Never"
    
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace('Z', '+00:00'))
        except:
            return dt
    
    # Format as readable datetime
    return dt.strftime("%Y-%m-%d %H:%M:%S")

def time_ago(dt):
    """Return human readable time ago string"""
    if dt is None:
        return "Never"
    
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace('Z', '+00:00'))
        except:
            return dt
    
    now = datetime.utcnow()
    diff = now - dt
    
    if diff.days > 0:
        return f"{diff.days} day{'s' if diff.days != 1 else ''} ago"
    elif diff.seconds > 3600:
        hours = diff.seconds // 3600
        return f"{hours} hour{'s' if hours != 1 else ''} ago"
    elif diff.seconds > 60:
        minutes = diff.seconds // 60
        return f"{minutes} minute{'s' if minutes != 1 else ''} ago"
    else:
        return "Just now"

def validate_username(username):
    """
    Validate username format
    Returns: (is_valid: bool, message: str)
    """
    if not username:
        return False, "Username is required"
    
    if len(username) < 3:
        return False, "Username must be at least 3 characters long"
    
    if len(username) > 50:
        return False, "Username must be less than 50 characters"
    
    # Allow only alphanumeric and underscore
    if not username.replace('_', '').isalnum():
        return False, "Username can only contain letters, numbers, and underscores"
    
    return True, "Username is valid"