import streamlit as st
from functools import wraps
from auth.audit_log import log_user_activity
from auth.utils import get_client_ip

# Define role hierarchy (higher number = more permissions)
ROLE_HIERARCHY = {
    'viewer': 1,
    'editor': 2, 
    'admin': 3,
    'super_admin': 4
}

# Define permissions for each role
ROLE_PERMISSIONS = {
    'viewer': [
        'view_dashboard',
        'view_reports',
        'view_own_profile'
    ],
    'editor': [
        'view_dashboard',
        'view_reports', 
        'view_own_profile',
        'create_records',
        'edit_records',
        'delete_own_records'
    ],
    'admin': [
        'view_dashboard',
        'view_reports',
        'view_own_profile',
        'create_records',
        'edit_records', 
        'delete_own_records',
        'delete_any_records',
        'manage_users',
        'view_audit_logs',
        'export_data'
    ],
    'super_admin': [
        'view_dashboard',
        'view_reports',
        'view_own_profile', 
        'create_records',
        'edit_records',
        'delete_own_records',
        'delete_any_records',
        'manage_users',
        'view_audit_logs',
        'export_data',
        'system_settings',
        'manage_roles',
        'delete_audit_logs'
    ]
}

def get_user_role():
    """Get current user's role from session"""
    return st.session_state.get('role', 'viewer')

def get_user_permissions():
    """Get current user's permissions"""
    role = get_user_role()
    return ROLE_PERMISSIONS.get(role, [])

def has_permission(permission):
    """Check if current user has specific permission"""
    user_permissions = get_user_permissions()
    return permission in user_permissions

def has_role(role):
    """Check if current user has specific role or higher"""
    user_role = get_user_role()
    user_level = ROLE_HIERARCHY.get(user_role, 0)
    required_level = ROLE_HIERARCHY.get(role, 0)
    return user_level >= required_level

def require_permission(permission):
    """Decorator to require specific permission"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not st.session_state.get('logged_in', False):
                st.error("Please login to access this feature.")
                return None
                
            if not has_permission(permission):
                user_role = get_user_role()
                username = st.session_state.get('username', 'Unknown')
                
                # Log access denial
                ip = get_client_ip()
                log_user_activity(
                    st.session_state.get('user_id'),
                    'access_denied',
                    ip,
                    {
                        'required_permission': permission,
                        'user_role': user_role,
                        'function': func.__name__
                    }
                )
                
                st.error(f"Access denied. Required permission: {permission}")
                st.info(f"Your role: {user_role}")
                return None
                
            return func(*args, **kwargs)
        return wrapper
    return decorator

def require_role(required_role):
    """Decorator to require specific role or higher"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if not st.session_state.get('logged_in', False):
                st.error("Please login to access this feature.")
                return None
                
            if not has_role(required_role):
                user_role = get_user_role()
                username = st.session_state.get('username', 'Unknown')
                
                # Log access denial
                ip = get_client_ip()
                log_user_activity(
                    st.session_state.get('user_id'),
                    'access_denied',
                    ip,
                    {
                        'required_role': required_role,
                        'user_role': user_role,
                        'function': func.__name__
                    }
                )
                
                st.error(f"Access denied. Required role: {required_role} or higher")
                st.info(f"Your role: {user_role}")
                return None
                
            return func(*args, **kwargs)
        return wrapper
    return decorator

def check_access_and_redirect(required_permission=None, required_role=None):
    """
    Check access and redirect if insufficient permissions
    Use this for page-level access control
    """
    if not st.session_state.get('logged_in', False):
        st.warning("Please login to access this page.")
        return False
    
    user_role = get_user_role()
    access_granted = True
    
    if required_permission and not has_permission(required_permission):
        access_granted = False
        error_msg = f"Access denied. Required permission: {required_permission}"
        
    elif required_role and not has_role(required_role):
        access_granted = False
        error_msg = f"Access denied. Required role: {required_role} or higher"
    
    if not access_granted:
        # Log access denial
        ip = get_client_ip()
        log_user_activity(
            st.session_state.get('user_id'),
            'page_access_denied',
            ip,
            {
                'required_permission': required_permission,
                'required_role': required_role,
                'user_role': user_role,
                'page': st.session_state.get('current_page', 'unknown')
            }
        )
        
        st.error(error_msg)
        st.info(f"Your current role: {user_role}")
        
        # Show available permissions
        user_permissions = get_user_permissions()
        if user_permissions:
            st.info("Your permissions:")
            for perm in user_permissions:
                st.write(f"• {perm}")
        
        return False
    
    return True

def display_role_info():
    """Display current user's role and permissions info"""
    if not st.session_state.get('logged_in', False):
        return
    
    user_role = get_user_role()
    user_permissions = get_user_permissions()
    
    with st.expander("Your Access Level", expanded=False):
        st.write(f"**Role:** {user_role.title()}")
        st.write(f"**Permission Level:** {ROLE_HIERARCHY.get(user_role, 0)}")
        
        st.write("**Your Permissions:**")
        for perm in user_permissions:
            st.write(f"{perm.replace('_', ' ').title()}")

def get_available_roles():
    """Get list of available roles for admin use"""
    return list(ROLE_HIERARCHY.keys())

def can_assign_role(target_role):
    """Check if current user can assign a specific role"""
    user_role = get_user_role()
    user_level = ROLE_HIERARCHY.get(user_role, 0)
    target_level = ROLE_HIERARCHY.get(target_role, 0)
    
    # Users can only assign roles lower than their own
    return user_level > target_level

def get_assignable_roles():
    """Get roles that current user can assign to others"""
    user_role = get_user_role()
    user_level = ROLE_HIERARCHY.get(user_role, 0)
    
    assignable = []
    for role, level in ROLE_HIERARCHY.items():
        if level < user_level:
            assignable.append(role)
    
    return assignable

def role_based_navigation():
    """Generate navigation menu based on user role"""
    if not st.session_state.get('logged_in', False):
        return []
    
    user_permissions = get_user_permissions()
    nav_items = []
    
    # Basic navigation for all users
    nav_items.append(("Dashboard", "dashboard"))
    
    if 'view_reports' in user_permissions:
        nav_items.append(("Reports", "reports"))
    
    if 'create_records' in user_permissions:
        nav_items.append(("Add Record", "add_record"))
    
    if 'manage_users' in user_permissions:
        nav_items.append(("Users", "users"))
    
    if 'view_audit_logs' in user_permissions:
        nav_items.append(("Audit Logs", "audit_logs"))
    
    if 'system_settings' in user_permissions:
        nav_items.append(("Settings", "settings"))
    
    # Profile is always available
    nav_items.append(("ofile", "profile"))
    
    return nav_items

def permission_info():
    """Return information about all permissions"""
    return {
        'view_dashboard': 'View main dashboard',
        'view_reports': 'View reports and analytics',
        'view_own_profile': 'View and edit own profile',
        'create_records': 'Create new records',
        'edit_records': 'Edit existing records',
        'delete_own_records': 'Delete own records',
        'delete_any_records': 'Delete any user records',
        'manage_users': 'Create, edit, delete users',
        'view_audit_logs': 'View system audit logs',
        'export_data': 'Export data to files',
        'system_settings': 'Modify system settings',
        'manage_roles': 'Assign roles to users',
        'delete_audit_logs': 'Delete audit log entries'
    }

def role_info():
    """Return information about all roles"""
    return {
        'viewer': 'Can view data and reports only',
        'editor': 'Can create and edit records',
        'admin': 'Can manage users and system functions',
        'super_admin': 'Full system access and control'
    }