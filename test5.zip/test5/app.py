import streamlit as st
from auth.login import login, logout, is_authenticated, get_current_user
from auth.register_user import register_user, manage_users
from auth.rbac import (check_access_and_redirect, display_role_info, role_based_navigation, require_permission)
from auth.audit_log import get_activity_stats, get_user_activities
from auth.utils import get_client_ip
import time

# Page configuration
st.set_page_config(
    page_title="Secure App",
    page_icon="🔐",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Inject custom CSS
def local_css(file_name):
    with open(file_name) as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

# Panggil fungsi dengan path ke file CSS
local_css("assets/styles/main.css")

def main():
    """Main application function"""
    
    # Initialize session state
    if 'current_page' not in st.session_state:
        st.session_state.current_page = 'dashboard'
    
    # Check authentication
    if not is_authenticated():
        show_login_page()
        return
    
    # Main app interface for authenticated users
    show_main_app()

def show_login_page():
    """Display login page"""
    st.markdown("""
    <div class="main-header">
        <h1> Secure Application</h1>
        <p>Please login to access the system</p>
    </div>
    """, unsafe_allow_html=True)
    
    # Center the login form
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        login()
    
    # Show some system info
    with st.expander(" System Information", expanded=False):
        st.write("**Default Admin Account:**")
        st.code("Username: admin\nPassword: Admin@123")
        st.warning(" Please change the default password after first login!")

def show_main_app():
    """Main application interface"""
    
    # Header with user info
    user = get_current_user()
    
    col1, col2, col3 = st.columns([2, 1, 1])
    
    with col1:
        st.markdown(f"""
        <div class="main-header">
            <h1>Secure Application Dashboard</h1>
            <p>Welcome back, {user['username']}!</p>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        display_role_info()
    
    with col3:
        if st.button("Logout", key="logout_btn"):
            logout()
    
    # Sidebar navigation
    show_sidebar_navigation()
    
    # Main content area
    show_page_content()

def show_sidebar_navigation():
    """Display sidebar navigation based on user role"""
    
    with st.sidebar:
        st.markdown("### Navigation")
        
        # Get role-based navigation items
        nav_items = role_based_navigation()
        
        # Current page indicator
        current_page = st.session_state.get('current_page', 'dashboard')
        
        for label, page_key in nav_items:
            if st.button(
                label, 
                key=f"nav_{page_key}",
                use_container_width=True,
                type="primary" if current_page == page_key else "secondary"
            ):
                st.session_state.current_page = page_key
                st.rerun()
        
        st.markdown("---")
        
        # User info in sidebar
        user = get_current_user()
        st.markdown("### 👤 User Info")
        st.write(f"**Username:** {user['username']}")
        st.write(f"**Role:** {user['role'].title()}")
        st.write(f"**ID:** {user['user_id']}")
        
        # Quick stats
        if st.checkbox("Show Quick Stats"):
            show_quick_stats()

def show_quick_stats():
    """Show quick statistics in sidebar"""
    try:
        stats = get_activity_stats(days=7)
        st.markdown("### 📊 This Week")
        st.metric("Total Activities", stats.get('total_activities', 0))
        st.metric("Active Users", stats.get('active_users', 0))
        if stats.get('failed_logins', 0) > 0:
            st.metric("Failed Logins", stats.get('failed_logins', 0), delta="")
    except:
        st.write("Stats unavailable")

def show_page_content():
    """Display content based on current page"""
    
    current_page = st.session_state.get('current_page', 'dashboard')
    
    if current_page == 'dashboard':
        show_dashboard()
    elif current_page == 'reports':
        show_reports()
    elif current_page == 'add_record':
        show_add_record()
    elif current_page == 'users':
        manage_users()
    elif current_page == 'register_user':
        register_user()
    elif current_page == 'audit_logs':
        show_audit_logs()
    elif current_page == 'settings':
        show_settings()
    elif current_page == 'profile':
        show_profile()
    else:
        st.error("Page not found")

def show_dashboard():
    """Dashboard page"""
    st.title("Dashboard")
    
    # Quick metrics
    col1, col2, col3, col4 = st.columns(4)
    
    try:
        stats = get_activity_stats(days=30)
        
        with col1:
            st.metric(
                "Total Activities", 
                stats.get('total_activities', 0),
                help="Total activities in last 30 days"
            )
        
        with col2:
            st.metric(
                "Active Users", 
                stats.get('active_users', 0),
                help="Unique active users in last 30 days"
            )
        
        with col3:
            st.metric(
                "Failed Logins", 
                stats.get('failed_logins', 0),
                delta="High" if stats.get('failed_logins', 0) > 10 else None
            )
        
        with col4:
            st.metric(
                "Your Activities", 
                len(get_user_activities(st.session_state.get('user_id'), limit=50)),
                help="Your activities in last 30 days"
            )
    
    except Exception as e:
        st.error(f"Error loading dashboard stats: {str(e)}")
    
    # Recent activity
    st.markdown("### Recent Activity")
    
    try:
        activities = get_user_activities(st.session_state.get('user_id'), limit=10)
        
        if activities:
            for activity in activities:
                with st.container():
                    col1, col2 = st.columns([3, 1])
                    with col1:
                        st.write(f"**{activity.get('action', 'Unknown')}**")
                        st.caption(f"Details: {activity.get('details', 'No details')}")
                    with col2:
                        st.caption(activity.get('timestamp', 'Unknown time'))
                    st.divider()
        else:
            st.info("No recent activities found.")
    
    except Exception as e:
        st.error(f"Error loading recent activities: {str(e)}")

@require_permission('view_reports')
def show_reports():
    """Reports page - requires view_reports permission"""
    st.title("Reports")
    
    # Time range selector
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start Date", value=time.time() - 30*24*3600)
    with col2:
        end_date = st.date_input("End Date", value=time.time())
    
    # Report type selector
    report_type = st.selectbox(
        "Report Type",
        ["User Activity", "Login Statistics", "System Usage", "Security Events"]
    )
    
    if st.button("Generate Report"):
        try:
            if report_type == "User Activity":
                st.subheader("User Activity Report")
                activities = get_user_activities(limit=100)
                
                if activities:
                    import pandas as pd
                    df = pd.DataFrame(activities)
                    st.dataframe(df, use_container_width=True)
                    
                    # Download button
                    csv = df.to_csv(index=False)
                    st.download_button(
                        label="Download CSV",
                        data=csv,
                        file_name=f"user_activity_{time.strftime('%Y%m%d')}.csv",
                        mime="text/csv"
                    )
                else:
                    st.info("No activity data found.")
            
            elif report_type == "Login Statistics":
                st.subheader("Login Statistics")
                stats = get_activity_stats(days=30)
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Successful Logins", stats.get('successful_logins', 0))
                with col2:
                    st.metric("Failed Logins", stats.get('failed_logins', 0))
                
                # Simple chart
                if st.checkbox("Show Chart"):
                    import matplotlib.pyplot as plt
                    fig, ax = plt.subplots()
                    labels = ['Successful', 'Failed']
                    values = [stats.get('successful_logins', 0), stats.get('failed_logins', 0)]
                    ax.pie(values, labels=labels, autopct='%1.1f%%')
                    st.pyplot(fig)
            
            else:
                st.info(f"Report generation for '{report_type}' is not yet implemented.")
        
        except Exception as e:
            st.error(f"Error generating report: {str(e)}")

@require_permission('add_records')
def show_add_record():
    """Add Record page - requires add_records permission"""
    st.title("Add New Record")
    
    with st.form("add_record_form"):
        st.subheader("Record Information")
        
        record_type = st.selectbox(
            "Record Type",
            ["Document", "Transaction", "User Data", "System Log", "Other"]
        )
        
        title = st.text_input("Title", placeholder="Enter record title")
        description = st.text_area("Description", placeholder="Enter record description")
        
        col1, col2 = st.columns(2)
        with col1:
            category = st.selectbox("Category", ["Important", "Normal", "Low Priority"])
        with col2:
            status = st.selectbox("Status", ["Active", "Pending", "Completed", "Archived"])
        
        tags = st.text_input("Tags (comma-separated)", placeholder="tag1, tag2, tag3")
        
        # File upload
        uploaded_file = st.file_uploader("Attach File (optional)", type=['pdf', 'docx', 'txt', 'csv'])
        
        submitted = st.form_submit_button("Add Record", type="primary")
        
        if submitted:
            if title and description:
                # Here you would typically save to database
                record_data = {
                    "type": record_type,
                    "title": title,
                    "description": description,
                    "category": category,
                    "status": status,
                    "tags": [tag.strip() for tag in tags.split(",") if tag.strip()],
                    "created_by": get_current_user()['username'],
                    "created_at": time.time()
                }
                
                # Log the activity
                from auth.audit_log import log_activity
                log_activity(
                    user_id=st.session_state.get('user_id'),
                    action="ADD_RECORD",
                    details=f"Added record: {title}",
                    ip_address=get_client_ip()
                )
                
                st.success("Record added successfully!")
                
                # Show added record details
                st.json(record_data)
                
                if uploaded_file:
                    st.info(f"File '{uploaded_file.name}' would be saved to storage.")
            else:
                st.error("Please fill in all required fields (Title and Description).")

@require_permission('view_audit_logs')
def show_audit_logs():
    """Audit Logs page - requires view_audit_logs permission"""
    st.title("Audit Logs")
    
    # Filters
    col1, col2, col3 = st.columns(3)
    
    with col1:
        user_filter = st.text_input("Filter by User", placeholder="Username")
    
    with col2:
        action_filter = st.selectbox(
            "Filter by Action",
            ["All", "LOGIN", "LOGOUT", "ADD_RECORD", "VIEW_PAGE", "FAILED_LOGIN"]
        )
    
    with col3:
        days_back = st.number_input("Days Back", min_value=1, max_value=365, value=30)
    
    if st.button("Load Logs"):
        try:
            # Get activities based on filters
            if user_filter:
                # This would typically query by username
                activities = get_user_activities(limit=100)
                # Filter by username (simplified)
                activities = [a for a in activities if user_filter.lower() in a.get('username', '').lower()]
            else:
                activities = get_user_activities(limit=100)
            
            # Filter by action
            if action_filter != "All":
                activities = [a for a in activities if a.get('action') == action_filter]
            
            if activities:
                st.subheader(f"Found {len(activities)} log entries")
                
                # Display logs in a table format
                for i, activity in enumerate(activities):
                    with st.expander(f"{i+1}. {activity.get('action', 'Unknown')} - {activity.get('timestamp', 'Unknown time')}"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write("**User:**", activity.get('username', 'Unknown'))
                            st.write("**Action:**", activity.get('action', 'Unknown'))
                            st.write("**IP Address:**", activity.get('ip_address', 'Unknown'))
                        
                        with col2:
                            st.write("**Timestamp:**", activity.get('timestamp', 'Unknown'))
                            st.write("**Details:**", activity.get('details', 'No details'))
                            if activity.get('success') is not None:
                                st.write("**Success:**", "Yes" if activity.get('success') else "No")
            else:
                st.info("No audit logs found matching the criteria.")
        
        except Exception as e:
            st.error(f"Error loading audit logs: {str(e)}")
    
    # Quick stats
    st.markdown("### Quick Statistics")
    try:
        stats = get_activity_stats(days=days_back)
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Activities", stats.get('total_activities', 0))
        with col2:
            st.metric("Unique Users", stats.get('active_users', 0))
        with col3:
            st.metric("Failed Logins", stats.get('failed_logins', 0))
        with col4:
            st.metric("Success Rate", f"{stats.get('success_rate', 0):.1f}%")
    
    except Exception as e:
        st.error(f"Error loading statistics: {str(e)}")

def show_settings():
    """Settings page"""
    st.title("Settings")
    
    user = get_current_user()
    
    # User preferences
    st.subheader("User Preferences")
    
    with st.form("user_preferences"):
        # Theme selection
        theme = st.selectbox("Theme", ["Light", "Dark", "Auto"])
        
        # Notification preferences
        email_notifications = st.checkbox("Email Notifications", value=True)
        desktop_notifications = st.checkbox("Desktop Notifications", value=False)
        
        # Language
        language = st.selectbox("Language", ["English", "Indonesian", "Spanish", "French"])
        
        # Timezone
        timezone = st.selectbox(
            "Timezone", 
            ["UTC", "Asia/Jakarta", "America/New_York", "Europe/London"]
        )
        
        if st.form_submit_button("Save Preferences"):
            # Here you would save preferences to database
            preferences = {
                "theme": theme,
                "email_notifications": email_notifications,
                "desktop_notifications": desktop_notifications,
                "language": language,
                "timezone": timezone
            }
            
            st.success("Preferences saved successfully!")
            st.json(preferences)
    
    st.divider()
    
    # Security settings
    st.subheader("Security Settings")
    
    with st.form("security_settings"):
        # Password change
        st.markdown("**Change Password**")
        current_password = st.text_input("Current Password", type="password")
        new_password = st.text_input("New Password", type="password")
        confirm_password = st.text_input("Confirm New Password", type="password")
        
        # Two-factor authentication
        st.markdown("**Two-Factor Authentication**")
        enable_2fa = st.checkbox("Enable 2FA", help="Requires authentication app")
        
        # Session timeout
        session_timeout = st.number_input(
            "Session Timeout (minutes)", 
            min_value=15, 
            max_value=480, 
            value=60
        )
        
        if st.form_submit_button("Update Security Settings"):
            if new_password and new_password != confirm_password:
                st.error("New passwords do not match!")
            elif new_password and len(new_password) < 8:
                st.error("Password must be at least 8 characters long!")
            else:
                # Here you would update security settings
                st.success("Security settings updated successfully!")
                
                # Log the activity
                from auth.audit_log import log_activity
                log_activity(
                    user_id=st.session_state.get('user_id'),
                    action="UPDATE_SECURITY",
                    details="Updated security settings",
                    ip_address=get_client_ip()
                )

def show_profile():
    """User profile page"""
    st.title("👤 User Profile")
    
    user = get_current_user()
    
    # Profile information
    col1, col2 = st.columns([1, 2])
    
    with col1:
        # Profile picture placeholder
        st.markdown("""
        <div style="
            width: 150px; 
            height: 150px; 
            border-radius: 50%; 
            background: linear-gradient(45deg, #667eea, #764ba2);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 48px;
            margin: 20px auto;
        ">
            {initial}
        </div>
        """.format(initial=user['username'][0].upper()), unsafe_allow_html=True)
        
        if st.button("Change Avatar"):
            st.info("Avatar upload feature coming soon!")
    
    with col2:
        st.markdown("### Profile Information")
        
        with st.form("profile_form"):
            username = st.text_input("Username", value=user['username'], disabled=True)
            email = st.text_input("Email", value=user.get('email', ''))
            full_name = st.text_input("Full Name", value=user.get('full_name', ''))
            phone = st.text_input("Phone", value=user.get('phone', ''))
            
            # Bio
            bio = st.text_area("Bio", value=user.get('bio', ''), height=100)
            
            # Location
            col1, col2 = st.columns(2)
            with col1:
                city = st.text_input("City", value=user.get('city', ''))
            with col2:
                country = st.text_input("Country", value=user.get('country', ''))
            
            if st.form_submit_button("Update Profile", type="primary"):
                # Here you would update the user profile in database
                updated_profile = {
                    "email": email,
                    "full_name": full_name,
                    "phone": phone,
                    "bio": bio,
                    "city": city,
                    "country": country,
                    "updated_at": time.time()
                }
                
                st.success("Profile updated successfully!")
                
                # Log the activity
                from auth.audit_log import log_activity
                log_activity(
                    user_id=st.session_state.get('user_id'),
                    action="UPDATE_PROFILE",
                    details="Updated user profile",
                    ip_address=get_client_ip()
                )
    
    st.divider()
    
    # Account statistics
    st.subheader("Account Statistics")
    
    col1, col2, col3 = st.columns(3)
    
    try:
        activities = get_user_activities(st.session_state.get('user_id'), limit=10)
        
        if activities:
            for activity in activities:
                with st.container():
                    col1, col2 = st.columns([3, 1])
                    with col1:
                        st.write(f"**{activity.get('action', 'Unknown')}**")
                        st.caption(f"Details: {activity.get('details', 'No details')}")
                    with col2:
                        st.caption(activity.get('timestamp', 'Unknown time'))
                    st.divider()
        else:
            st.info("No recent activities found.")
    
    except Exception as e:
        st.error(f"Error loading recent activities: {str(e)}")

@require_permission('view_reports')
def show_reports():
    """Reports page - requires view_reports permission"""
    st.title("Reports")
    
    # Time range selector
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start Date", value=time.time() - 30*24*3600)
    with col2:
        end_date = st.date_input("End Date", value=time.time())
    
    # Report type selector
    report_type = st.selectbox(
        "Report Type",
        ["User Activity", "Login Statistics", "System Usage", "Security Events"]
    )
    
    if st.button("Generate Report"):
        try:
            if report_type == "User Activity":
                st.subheader("User Activity Report")
                activities = get_user_activities(limit=100)
                
                if activities:
                    import pandas as pd
                    df = pd.DataFrame(activities)
                    st.dataframe(df, use_container_width=True)
                    
                    # Download button
                    csv = df.to_csv(index=False)
                    st.download_button(
                        label="Download CSV",
                        data=csv,
                        file_name=f"user_activity_{time.strftime('%Y%m%d')}.csv",
                        mime="text/csv"
                    )
                else:
                    st.info("No activity data found.")
            
            elif report_type == "Login Statistics":
                st.subheader("Login Statistics")
                stats = get_activity_stats(days=30)
                
                col1, col2 = st.columns(2)
                with col1:
                    st.metric("Successful Logins", stats.get('successful_logins', 0))
                with col2:
                    st.metric("Failed Logins", stats.get('failed_logins', 0))
                
                # Simple chart
                if st.checkbox("Show Chart"):
                    import matplotlib.pyplot as plt
                    fig, ax = plt.subplots()
                    labels = ['Successful', 'Failed']
                    values = [stats.get('successful_logins', 0), stats.get('failed_logins', 0)]
                    ax.pie(values, labels=labels, autopct='%1.1f%%')
                    st.pyplot(fig)
            
            else:
                st.info(f"Report generation for '{report_type}' is not yet implemented.")
        
        except Exception as e:
            st.error(f"Error generating report: {str(e)}")

@require_permission('add_records')
def show_add_record():
    """Add Record page - requires add_records permission"""
    st.title("Add New Record")
    
    with st.form("add_record_form"):
        st.subheader("Record Information")
        
        record_type = st.selectbox(
            "Record Type",
            ["Document", "Transaction", "User Data", "System Log", "Other"]
        )
        
        title = st.text_input("Title", placeholder="Enter record title")
        description = st.text_area("Description", placeholder="Enter record description")
        
        col1, col2 = st.columns(2)
        with col1:
            category = st.selectbox("Category", ["Important", "Normal", "Low Priority"])
        with col2:
            status = st.selectbox("Status", ["Active", "Pending", "Completed", "Archived"])
        
        tags = st.text_input("Tags (comma-separated)", placeholder="tag1, tag2, tag3")
        
        # File upload
        uploaded_file = st.file_uploader("Attach File (optional)", type=['pdf', 'docx', 'txt', 'csv'])
        
        submitted = st.form_submit_button("Add Record", type="primary")
        
        if submitted:
            if title and description:
                # Here you would typically save to database
                record_data = {
                    "type": record_type,
                    "title": title,
                    "description": description,
                    "category": category,
                    "status": status,
                    "tags": [tag.strip() for tag in tags.split(",") if tag.strip()],
                    "created_by": get_current_user()['username'],
                    "created_at": time.time()
                }
                
                # Log the activity
                from auth.audit_log import log_activity
                log_activity(
                    user_id=st.session_state.get('user_id'),
                    action="ADD_RECORD",
                    details=f"Added record: {title}",
                    ip_address=get_client_ip()
                )
                
                st.success("Record added successfully!")
                
                # Show added record details
                st.json(record_data)
                
                if uploaded_file:
                    st.info(f"File '{uploaded_file.name}' would be saved to storage.")
            else:
                st.error("Please fill in all required fields (Title and Description).")

@require_permission('view_audit_logs')
def show_audit_logs():
    """Audit Logs page - requires view_audit_logs permission"""
    st.title("Audit Logs")
    
    # Filters
    col1, col2, col3 = st.columns(3)
    
    with col1:
        user_filter = st.text_input("Filter by User", placeholder="Username")
    
    with col2:
        action_filter = st.selectbox(
            "Filter by Action",
            ["All", "LOGIN", "LOGOUT", "ADD_RECORD", "VIEW_PAGE", "FAILED_LOGIN"]
        )
    
    with col3:
        days_back = st.number_input("Days Back", min_value=1, max_value=365, value=30)
    
    if st.button("Load Logs"):
        try:
            # Get activities based on filters
            if user_filter:
                # This would typically query by username
                activities = get_user_activities(limit=100)
                # Filter by username (simplified)
                activities = [a for a in activities if user_filter.lower() in a.get('username', '').lower()]
            else:
                activities = get_user_activities(limit=100)
            
            # Filter by action
            if action_filter != "All":
                activities = [a for a in activities if a.get('action') == action_filter]
            
            if activities:
                st.subheader(f"Found {len(activities)} log entries")
                
                # Display logs in a table format
                for i, activity in enumerate(activities):
                    with st.expander(f"{i+1}. {activity.get('action', 'Unknown')} - {activity.get('timestamp', 'Unknown time')}"):
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            st.write("**User:**", activity.get('username', 'Unknown'))
                            st.write("**Action:**", activity.get('action', 'Unknown'))
                            st.write("**IP Address:**", activity.get('ip_address', 'Unknown'))
                        
                        with col2:
                            st.write("**Timestamp:**", activity.get('timestamp', 'Unknown'))
                            st.write("**Details:**", activity.get('details', 'No details'))
                            if activity.get('success') is not None:
                                st.write("**Success:**", "Yes" if activity.get('success') else "No")
            else:
                st.info("No audit logs found matching the criteria.")
        
        except Exception as e:
            st.error(f"Error loading audit logs: {str(e)}")
    
    # Quick stats
    st.markdown("### 📊 Quick Statistics")
    try:
        stats = get_activity_stats(days=days_back)
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Activities", stats.get('total_activities', 0))
        with col2:
            st.metric("Unique Users", stats.get('active_users', 0))
        with col3:
            st.metric("Failed Logins", stats.get('failed_logins', 0))
        with col4:
            st.metric("Success Rate", f"{stats.get('success_rate', 0):.1f}%")
    
    except Exception as e:
        st.error(f"Error loading statistics: {str(e)}")

def show_settings():
    """Settings page"""
    st.title("⚙️ Settings")
    
    user = get_current_user()
    
    # User preferences
    st.subheader("User Preferences")
    
    with st.form("user_preferences"):
        # Theme selection
        theme = st.selectbox("Theme", ["Light", "Dark", "Auto"])
        
        # Notification preferences
        email_notifications = st.checkbox("Email Notifications", value=True)
        desktop_notifications = st.checkbox("Desktop Notifications", value=False)
        
        # Language
        language = st.selectbox("Language", ["English", "Indonesian", "Spanish", "French"])
        
        # Timezone
        timezone = st.selectbox(
            "Timezone", 
            ["UTC", "Asia/Jakarta", "America/New_York", "Europe/London"]
        )
        
        if st.form_submit_button("Save Preferences"):
            # Here you would save preferences to database
            preferences = {
                "theme": theme,
                "email_notifications": email_notifications,
                "desktop_notifications": desktop_notifications,
                "language": language,
                "timezone": timezone
            }
            
            st.success("Preferences saved successfully!")
            st.json(preferences)
    
    st.divider()
    
    # Security settings
    st.subheader("Security Settings")
    
    with st.form("security_settings"):
        # Password change
        st.markdown("**Change Password**")
        current_password = st.text_input("Current Password", type="password")
        new_password = st.text_input("New Password", type="password")
        confirm_password = st.text_input("Confirm New Password", type="password")
        
        # Two-factor authentication
        st.markdown("**Two-Factor Authentication**")
        enable_2fa = st.checkbox("Enable 2FA", help="Requires authentication app")
        
        # Session timeout
        session_timeout = st.number_input(
            "Session Timeout (minutes)", 
            min_value=15, 
            max_value=480, 
            value=60
        )
        
        if st.form_submit_button("Update Security Settings"):
            if new_password and new_password != confirm_password:
                st.error("New passwords do not match!")
            elif new_password and len(new_password) < 8:
                st.error("Password must be at least 8 characters long!")
            else:
                # Here you would update security settings
                st.success("Security settings updated successfully!")
                
                # Log the activity
                from auth.audit_log import log_activity
                log_activity(
                    user_id=st.session_state.get('user_id'),
                    action="UPDATE_SECURITY",
                    details="Updated security settings",
                    ip_address=get_client_ip()
                )

def show_profile():
    """User profile page"""
    st.title("👤 User Profile")
    
    user = get_current_user()
    
    # Profile information
    col1, col2 = st.columns([1, 2])
    
    with col1:
        # Profile picture - check if user has avatar file
        avatar_path = user.get('avatar', None)
        
        if avatar_path:
            try:
                # Try to display existing avatar
                st.image(avatar_path, width=150, caption="Profile Picture")
            except:
                # Fallback if file not found
                st.markdown("""
                <div style="
                    width: 150px; 
                    height: 150px; 
                    border-radius: 50%; 
                    background: linear-gradient(45deg, #667eea, #764ba2);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    color: white;
                    font-size: 48px;
                    margin: 20px auto;
                ">
                    {initial}
                </div>
                """.format(initial=user['username'][0].upper()), unsafe_allow_html=True)
                st.caption("Avatar file not found")
        else:
            # Default avatar placeholder
            st.markdown("""
            <div style="
                width: 150px; 
                height: 150px; 
                border-radius: 50%; 
                background: linear-gradient(45deg, #667eea, #764ba2);
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 48px;
                margin: 20px auto;
            ">
                {initial}
            </div>
            """.format(initial=user['username'][0].upper()), unsafe_allow_html=True)
        
        # Avatar upload/change
        uploaded_avatar = st.file_uploader(
            "Change Avatar", 
            type=['png', 'jpg', 'jpeg', 'gif'],
            help="Upload a new profile picture"
        )
        
        if uploaded_avatar:
            # Preview new avatar
            st.image(uploaded_avatar, width=150, caption="New Avatar Preview")
            
            if st.button("Save New Avatar"):
                st.success("Avatar updated successfully!")
                
                # Log the activity
                from auth.audit_log import log_activity
                log_activity(
                    user_id=st.session_state.get('user_id'),
                    action="UPDATE_AVATAR",
                    details=f"Updated profile avatar: {uploaded_avatar.name}",
                    ip_address=get_client_ip()
                )
    
    with col2:
        st.markdown("### Profile Information")
        
        with st.form("profile_form"):
            username = st.text_input("Username", value=user['username'], disabled=True)
            email = st.text_input("Email", value=user.get('email', ''))
            full_name = st.text_input("Full Name", value=user.get('full_name', ''))
            phone = st.text_input("Phone", value=user.get('phone', ''))
            
            # Bio
            bio = st.text_area("Bio", value=user.get('bio', ''), height=100)
            
            # Location
            col1, col2 = st.columns(2)
            with col1:
                city = st.text_input("City", value=user.get('city', ''))
            with col2:
                country = st.text_input("Country", value=user.get('country', ''))
            
            if st.form_submit_button("Update Profile", type="primary"):
                # Here you would update the user profile in database
                updated_profile = {
                    "email": email,
                    "full_name": full_name,
                    "phone": phone,
                    "bio": bio,
                    "city": city,
                    "country": country,
                    "updated_at": time.time()
                }
                
                st.success("✅ Profile updated successfully!")
                
                # Log the activity
                from auth.audit_log import log_activity
                log_activity(
                    user_id=st.session_state.get('user_id'),
                    action="UPDATE_PROFILE",
                    details="Updated user profile",
                    ip_address=get_client_ip()
                )
    
    st.divider()
    
    # Account statistics
    st.subheader("📊 Account Statistics")
    
    col1, col2, col3 = st.columns(3)
    
    try:
        user_activities = get_user_activities(st.session_state.get('user_id'), limit=1000)
        
        with col1:
            st.metric("Total Activities", len(user_activities))
        
        with col2:
            # Last login (simplified)
            login_activities = [a for a in user_activities if a.get('action') == 'LOGIN']
            last_login = login_activities[0]['timestamp'] if login_activities else "Never"
            st.metric("Last Login", last_login)
        
        with col3:
            # Account age (simplified - would need creation date from user data)
            st.metric("Member Since", user.get('created_at', 'Unknown'))
    
    except Exception as e:
        st.error(f"Error loading account statistics: {str(e)}")

# Run the application
if __name__ == "__main__":
    main()