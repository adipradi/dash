import os
from db_connection import get_connection

def run_mysql_schema():
    schema_file_path = os.path.join(os.path.dirname(__file__), 'mysql_schema.sql')

    # Baca seluruh isi file SQL
    with open(schema_file_path, 'r', encoding='utf-8') as f:
        sql_script = f.read()

    # Pisahkan tiap statement dengan delimiter ;
    sql_statements = sql_script.split(';')

    conn = get_connection()
    cursor = conn.cursor()

    try:
        for statement in sql_statements:
            stmt = statement.strip()
            if stmt:
                print(f"Menjalankan: {stmt[:60]}...")
                cursor.execute(stmt)
        conn.commit()
        print("Semua perintah SQL berhasil dijalankan.")
    except Exception as e:
        print("Terjadi kesalahan saat menjalankan SQL:", e)
        conn.rollback()
    finally:
        cursor.close()
        conn.close()

if __name__ == '__main__':
    run_mysql_schema()
