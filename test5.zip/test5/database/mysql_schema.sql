-- =========================
-- USERS TABLE
-- =========================
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(512) NOT NULL,
    role VARCHAR(20) DEFAULT 'viewer',
    email VARCHAR(100),
    full_name VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login DATETIME NULL,
    failed_login_attempts INT DEFAULT 0,
    locked_until DATETIME NULL,
    
    INDEX idx_username (username),
    INDEX idx_role (role),
    INDEX idx_active (is_active),
    INDEX idx_last_login (last_login)
);

-- =========================
-- AUDIT LOGS TABLE
-- =========================
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NULL,
    action VARCHAR(50) NOT NULL,
    ip_address VARCHAR(100),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    metadata TEXT,
    session_id VARCHAR(100),
    user_agent TEXT,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,

    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_timestamp (timestamp),
    INDEX idx_ip_address (ip_address),
    INDEX idx_session_id (session_id)
);

-- =========================
-- USER SESSIONS TABLE
-- =========================
CREATE TABLE IF NOT EXISTS user_sessions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    session_token VARCHAR(255) UNIQUE NOT NULL,
    ip_address VARCHAR(100),
    user_agent TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,

    INDEX idx_user_id (user_id),
    INDEX idx_session_token (session_token),
    INDEX idx_expires_at (expires_at),
    INDEX idx_active (is_active)
);

-- =========================
-- USER PREFERENCES TABLE
-- =========================
CREATE TABLE IF NOT EXISTS user_preferences (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    preference_key VARCHAR(100) NOT NULL,
    preference_value TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,

    UNIQUE KEY unique_user_preference (user_id, preference_key),

    INDEX idx_user_id (user_id),
    INDEX idx_preference_key (preference_key)
);

-- =========================
-- PASSWORD RESET TOKENS
-- =========================
CREATE TABLE IF NOT EXISTS password_reset_tokens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    token VARCHAR(255) UNIQUE NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,

    INDEX idx_user_id (user_id),
    INDEX idx_token (token),
    INDEX idx_expires_at (expires_at)
);

-- =========================
-- DEFAULT ADMIN INSERT
-- (Ganti hash sesuai sistemmu)
-- =========================
INSERT INTO users (username, password_hash, role, email, full_name)
VALUES (
    'admin',
    'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3:5f4dcc3b5aa765d61d8327deb882cf99',
    'super_admin',
    'admin@system.local',
    'System Administrator'
)
ON DUPLICATE KEY UPDATE 
    password_hash = VALUES(password_hash),
    role = VALUES(role),
    email = VALUES(email),
    full_name = VALUES(full_name);

-- =========================
-- INDEX FOR CLEANUP
-- =========================
CREATE INDEX IF NOT EXISTS idx_audit_logs_cleanup ON audit_logs(timestamp);

-- =========================
-- ACTIVE USERS VIEW
-- =========================
CREATE OR REPLACE VIEW active_users AS
SELECT 
    id,
    username,
    role,
    email,
    full_name,
    created_at,
    last_login,
    CASE 
        WHEN last_login >= DATE_SUB(NOW(), INTERVAL 30 DAY) THEN 'Active'
        WHEN last_login >= DATE_SUB(NOW(), INTERVAL 90 DAY) THEN 'Inactive'
        ELSE 'Dormant'
    END AS status
FROM users 
WHERE is_active = TRUE;

-- =========================
-- SECURITY SUMMARY VIEW
-- =========================
CREATE OR REPLACE VIEW security_summary AS
SELECT 
    DATE(timestamp) AS log_date,
    action,
    COUNT(*) AS count,
    COUNT(DISTINCT ip_address) AS unique_ips,
    COUNT(DISTINCT user_id) AS unique_users
FROM audit_logs 
WHERE timestamp >= DATE_SUB(NOW(), INTERVAL 30 DAY)
GROUP BY DATE(timestamp), action
ORDER BY log_date DESC, count DESC;
